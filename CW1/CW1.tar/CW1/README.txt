1. demo.py is the script to create the plots for Q1
2. Q4.py is the script for Q4
3. pred_fitness.py and prey_fitness are the script for Q6
4. A little changes for mouse.cc and chase.cc file